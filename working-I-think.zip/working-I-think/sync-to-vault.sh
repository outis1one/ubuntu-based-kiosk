#!/bin/bash
# Sync.com Vault Automation - Linux Orchestrator
# Simplified Flow: Prepare Files -> Set Trigger -> Start Windows -> Wait -> Cleanup

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# --- Configuration ---
if [ ! -f .env ]; then echo "Error: .env file not found."; exit 1; fi
source .env

SYNC_ROOT_NAME="${SYNC_ROOT_FOLDER_NAME:-LinuxData}"
INCOMING_FOLDER="$LINUX_SHARED_FOLDER/$SYNC_ROOT_NAME"
LOG_FILE="./logs/sync-$(date +%Y%m%d-%H%M%S).log"

# --- Helpers ---
log() { echo -e "\033[0;32m[$(date +'%T')]\033[0m $1" | tee -a "$LOG_FILE"; }
error() { echo -e "\033[0;31m[$(date +'%T')] ERROR:\033[0m $1" | tee -a "$LOG_FILE"; }

# --- 1. Prepare Environment ---
log "=== Starting Sync ==="
mkdir -p "$INCOMING_FOLDER" "$LINUX_SHARED_FOLDER/scripts" ./logs

# Copy scripts to shared so Windows can see them
cp -f ./windows-scripts/*.ps1 "$LINUX_SHARED_FOLDER/scripts/" 2>/dev/null || true
cp -f ./windows-scripts/*.ahk "$LINUX_SHARED_FOLDER/scripts/" 2>/dev/null || true

# Clean old status markers
rm -f "$INCOMING_FOLDER/.upload_complete" "$INCOMING_FOLDER/.start_automation" "$INCOMING_FOLDER/.automation_processing"

# --- 2. Encrypt & Copy Files ---
log "Encrypting and copying files to $SYNC_ROOT_NAME..."
# Clear old data
rm -rf "$INCOMING_FOLDER"/*

IFS=',' read -ra PATHS <<< "$SOURCE_PATHS"
for source_path in "${PATHS[@]}"; do
    source_path=$(eval echo "$source_path")
    if [ -e "$source_path" ]; then
        log "Processing: $source_path"
        # Preserve directory structure
        dest_path="$INCOMING_FOLDER$source_path"
        if [ -d "$source_path" ]; then
            rclone copy "$source_path" "$dest_path" --progress --transfers 4
        else
            rclone copy "$source_path" "$(dirname "$dest_path")" --progress
        fi
    fi
done

# --- 3. Set the Trigger ---
# We set this NOW. Windows will find it whenever it is ready.
touch "$INCOMING_FOLDER/.start_automation"
log "Trigger set. Files are ready for pickup."

# --- 4. Start Windows ---
# Set hostname for clean vault path
if [ -z "$WINDOWS_HOSTNAME" ]; then WINDOWS_HOSTNAME="$(hostname)-win"; fi
export win_hostname="$WINDOWS_HOSTNAME"

if docker ps | grep -q "$DOCKER_CONTAINER_NAME"; then
    log "Windows container is already running. It should pick up the trigger automatically."
    CONTAINER_NEW=false
else
    log "Starting Windows container (Hostname: $WINDOWS_HOSTNAME)..."
    docker compose up -d
    CONTAINER_NEW=true
fi

# Start VNC Keep-alive (Recommended for AHK reliability)
if command -v chromium-browser &> /dev/null; then
    chromium-browser --headless --disable-gpu "http://localhost:${VNC_PORT:-8006}" &> /dev/null &
    VNC_PID=$!
fi

# --- 5. Wait for Completion ---
log "Waiting for upload confirmation..."
log "Monitor Windows Log: tail -f $LINUX_SHARED_FOLDER/windows-debug.log"

TIMEOUT=${SYNC_VAULT_CONFIRMATION_TIMEOUT:-7200}
WAITED=0

while [ $WAITED -lt $TIMEOUT ]; do
    if [ -f "$INCOMING_FOLDER/.upload_complete" ]; then
        log "SUCCESS: Upload confirmed by Windows."
        break
    fi
    
    sleep 30
    WAITED=$((WAITED + 30))
    
    if [ $((WAITED % 300)) -eq 0 ]; then
        log "Still waiting... (${WAITED}s / ${TIMEOUT}s)"
    fi
done

if [ ! -f "$INCOMING_FOLDER/.upload_complete" ]; then
    error "Timed out waiting for upload."
fi

# --- 6. Cleanup ---
log "Cleaning up..."

if [ -n "$VNC_PID" ]; then kill "$VNC_PID" 2>/dev/null; fi

if [ -f "$INCOMING_FOLDER/.upload_complete" ] && [ "$DELETE_ENCRYPTED_AFTER_SYNC" = "true" ]; then
    log "Deleting encrypted files..."
    rm -rf "$INCOMING_FOLDER"/*
fi

if [ "$CONTAINER_NEW" = "true" ]; then
    log "Stopping Windows container..."
    docker compose down
fi

log "Done."
