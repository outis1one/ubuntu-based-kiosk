# Sync.com Vault Automation - Watcher Script
$ErrorActionPreference = "Continue"

# --- Configuration ---
$SyncFolderName = "LinuxData" 
$CleanPath = "C:\$SyncFolderName"
$BootWaitSeconds = 300  # 5 Minutes

# --- Logging ---
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$SharedDir = Join-Path $DesktopPath "Shared"
$LogFile = Join-Path $SharedDir "windows-debug.log"

function Write-Log {
    param([string]$Message)
    $TimeStamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogLine = "[$TimeStamp] $Message"
    try { Write-Host $LogLine -ForegroundColor Cyan; Add-Content -Path $LogFile -Value $LogLine -Force -ErrorAction SilentlyContinue } catch {}
}

# --- Phase 1: Boot Wait ---
Write-Log "=== Automation Script Started ==="
Write-Log "Waiting $BootWaitSeconds seconds for Windows stability..."
Start-Sleep -Seconds $BootWaitSeconds
Write-Log "Boot wait complete. Checking for files."

# --- Setup ---
$SourceDir = Join-Path $SharedDir $SyncFolderName
if (-not (Test-Path $SourceDir)) { New-Item -ItemType Directory -Path $SourceDir -Force | Out-Null }
if (-not (Test-Path $CleanPath)) { cmd /c mklink /J "$CleanPath" "$SourceDir" | Out-Null }

$TriggerFile = Join-Path $CleanPath ".start_automation"
$UploadCompleteFile = Join-Path $CleanPath ".upload_complete"

# Ensure Sync.com Running
if (-not (Get-Process "Sync" -ErrorAction SilentlyContinue)) {
    Start-Process "C:\Program Files\Sync\Sync.exe" -ErrorAction SilentlyContinue
    Start-Process "C:\Program Files (x86)\Sync\Sync.exe" -ErrorAction SilentlyContinue
}

# --- Phase 2: Watch Loop ---
Write-Log "Watching for trigger ($TriggerFile)"

while ($true) {
    if (Test-Path $TriggerFile) {
        Write-Log "!!! TRIGGER FOUND !!!"
        
        # 1. Close ALL Explorer windows (Fresh Start)
        try { (New-Object -ComObject Shell.Application).Windows() | ForEach-Object { $_.Quit() } } catch {}
        Start-Sleep -Seconds 2

        # 2. Open Folder
        Invoke-Item $CleanPath
        Start-Sleep -Seconds 3

        # 3. Run AHK
        $AhkScript = Join-Path $SharedDir "scripts\send-to-vault.ahk"
        if (Test-Path $AhkScript) {
            Write-Log "Launching AHK..."
            Start-Process "C:\Program Files\AutoHotkey\AutoHotkey.exe" -ArgumentList "`"$AhkScript`" `"$SyncFolderName`""
        } else { Write-Log "ERROR: AHK Script missing!" }

        # 4. Rename Trigger
        Rename-Item -Path $TriggerFile -NewName ".automation_processing" -Force
        
        # 5. Wait for AHK
        Start-Sleep -Seconds 45

        # 6. Signal Done
        New-Item -Path $UploadCompleteFile -ItemType File -Force | Out-Null
        Write-Log "Batch Complete. Signal sent to Linux."
    }
    Start-Sleep -Seconds 5
}
