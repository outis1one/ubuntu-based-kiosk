# Windows Setup Script
# Run this ONCE manually inside the Windows container

$ErrorActionPreference = "Stop"
Write-Host "=== Sync.com Vault Automation - Windows Setup ===" -ForegroundColor Cyan

# 1. Check Admin
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell -ArgumentList "-ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# 2. Config & Directories
$username = $env:USERNAME
$syncFolderName = "LinuxData"  # Must match .env
$scriptsDir = "C:\SyncAutomation"
# This is where the scripts live physically (from Linux)
$sharedScriptsDir = "C:\Users\$username\Desktop\Shared\scripts"
$physicalDataDir = "C:\Users\$username\Desktop\Shared\$syncFolderName"
$cleanDataPath = "C:\$syncFolderName"

# Create Directories
if (-not (Test-Path $scriptsDir)) { New-Item -ItemType Directory -Path $scriptsDir -Force | Out-Null }
if (-not (Test-Path $physicalDataDir)) { New-Item -ItemType Directory -Path $physicalDataDir -Force | Out-Null }

# 3. Create Junction (C:\LinuxData -> Desktop\Shared\LinuxData)
if (-not (Test-Path $cleanDataPath)) {
    Write-Host "Creating Junction: $cleanDataPath" -ForegroundColor Green
    cmd /c mklink /J "$cleanDataPath" "$physicalDataDir" | Out-Null
} else {
    Write-Host "Junction already exists: $cleanDataPath" -ForegroundColor Gray
}

# 4. Install Dependencies
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine -Force
if (-not (Get-Command choco -ErrorAction SilentlyContinue)) {
    [System.Net.ServicePointManager]::SecurityProtocol = 3072
    Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
}
if (-not (Get-Command autohotkey -ErrorAction SilentlyContinue)) { choco install autohotkey -y }

# 5. Install Scripts
Write-Host "Verifying scripts..." -ForegroundColor Green

# We only copy to the local backup folder (C:\SyncAutomation)
# We do NOT copy to $sharedScriptsDir because the files are already there!
if (Test-Path "$sharedScriptsDir\send-to-vault.ahk") {
    Copy-Item "$sharedScriptsDir\send-to-vault.ahk" "$scriptsDir\" -Force
    Write-Host "AHK script backed up to C:\SyncAutomation" -ForegroundColor Gray
} else {
    Write-Host "WARNING: send-to-vault.ahk not found in shared folder!" -ForegroundColor Yellow
}

if (-not (Test-Path "$sharedScriptsDir\automate-vault.ps1")) {
    Write-Host "ERROR: automate-vault.ps1 not found in $sharedScriptsDir" -ForegroundColor Red
    Write-Host "Please ensure the Linux script has copied the files correctly." -ForegroundColor Yellow
    exit 1
}

# 6. Create Scheduled Task (Runs on Login)
$taskName = "SyncVaultAutomation"
Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue

# We point the task directly to the script in the Shared folder
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$sharedScriptsDir\automate-vault.ps1`""
$trigger = New-ScheduledTaskTrigger -AtLogOn
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal (New-ScheduledTaskPrincipal -UserId $username -LogonType Interactive -RunLevel Highest) -Settings $settings | Out-Null

# 7. Power Settings
powercfg -change -standby-timeout-ac 0
powercfg -change -hibernate-timeout-ac 0

Write-Host "=== Setup Complete ===" -ForegroundColor Cyan
Write-Host "Junction Verified: $cleanDataPath"
Write-Host "Scheduled Task Created: $taskName"
Read-Host "Press Enter to exit...
